const firstErrorField = document.querySelector('.has-error');
if (firstErrorField) {
    firstErrorField.focus();
}